﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigitalWallet.Models
{
    public class SendMoney
    {
        public int UserId { get; set; }
        public string ReceiverPhone { get; set; }
        public float Amount { get; set; }
        public string Comment { get; set; }
    }
}
