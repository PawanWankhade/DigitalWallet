﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigitalWallet.Models
{
    public class Wallet
    {
        public int WalletId { get; set; }
        public int UserId { get; set; }
        public float Amount{ get; set; }
    }
}