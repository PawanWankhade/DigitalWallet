﻿using DigitalWallet.Models;
using OnlineDigitalWallet.DataAccess;
using OnlineDigitalWallet.Scripts;
using OnlineDigitalWallet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace OnlineDigitalWallet.Models
{
    public class DbContext
    {
        public int SignUpUser(object data)
        {
            int userId = 0;
            try
            {
                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                Users user = json_serializer.Deserialize<Users>(data.ToString());
                userId = (new DataAccessLayer().RegisterUser(user));
            }
            catch (Exception)
            {

            }
            return userId;
        }
        public int Login(object data)
        {
            int userId = 0;
            try
            {
                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                Credentials c = json_serializer.Deserialize<Credentials>(data.ToString());
                userId = (new DataAccessLayer().Authenticate(c));

            }
            catch (Exception ex)
            {

            }
            return userId;
        }
        public Users GetUserById(int id)
        {
            Users user = new DataAccessLayer().GetUserById(id);
            return user;
        }

        public Wallet GetWalletById(int id)
        {
            Wallet wallet = new DataAccessLayer().GetWalletById(id);
            return wallet;
        }

        public bool AddMoney(int id, float amount)
        {
            try
            {
                new DataAccessLayer().AddMoney(id, amount);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string SendMoney(int id, object data)
        {
            try
            {
                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                SendMoney sendMoney = json_serializer.Deserialize<SendMoney>(data.ToString());
                string userName = new DataAccessLayer().SendMoney(id, sendMoney);
                return userName;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public Users GetUserByPhone(string phone)
        {
            Users user = new Users()
            {
                Email = "pawan.live.com",
                Phone = "7620384419"
            };
            return user;
        }

        public List<Transaction> GetTransactions(int id)
        {
            List<Transaction> transactions = new DataAccessLayer().GetTransactions(id);
            return transactions;
        }
    }
}