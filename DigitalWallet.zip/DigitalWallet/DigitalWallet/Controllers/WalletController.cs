﻿using OnlineDigitalWallet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DigitalWallet.Controllers
{
    public class WalletController : ApiController
    {
        // GET: api/Wallet
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Wallet/5
        public IHttpActionResult Get(int id)
        {
            var Wallet = new DbContext().GetWalletById(id);
            return Ok(Wallet);
        }

        // POST: api/Wallet
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Wallet/5
        public void Put(int id, object amount)
        {
            new DbContext().AddMoney(id, (float)Convert.ToDouble(amount));
        }

        // DELETE: api/Wallet/5
        public void Delete(int id)
        {
        }
    }
}
