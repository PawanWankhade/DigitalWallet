﻿using DigitalWallet.Models;
using OnlineDigitalWallet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DigitalWallet.Controllers
{
    public class TransactionController : ApiController
    {
        // GET: api/Transaction
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Transaction/5
        public IHttpActionResult Get(int id)
        {
            List<Transaction> transactions = new DbContext().GetTransactions(id);
            //if (transaction == null)
            {
              //  return NotFound();
            }
            //else
            {
                return Ok(transactions);
            }
        }

        // POST: api/Transaction
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Transaction/5
        public string Put(int id, object data)
        {
           return(new DbContext().SendMoney(id, data));
        }

        // DELETE: api/Transaction/5
        public void Delete(int id)
        {
        }
    }
}
