﻿using OnlineDigitalWallet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OnlineDigitalWallet.Controllers
{
    public class UsersController : ApiController
    {
        // GET: api/Users
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Users/5
        public IHttpActionResult Get(int id)
        {
            var User = new DbContext().GetUserById(id);
            return Ok(User);
        }
        // POST: api/Users
        public bool Post(object data)
        {
            int userId = 0;
            try
            {
                DbContext dbContext = new DbContext();
                userId = dbContext.SignUpUser(data);
            }
            catch (Exception ex)
            {
            }
            if (userId != 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        // PUT: api/Users/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Users/5
        public void Delete(int id)
        {
        }
    }
}
