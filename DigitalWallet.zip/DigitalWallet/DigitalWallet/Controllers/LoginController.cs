﻿using OnlineDigitalWallet.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace OnlineDigitalWallet.Controllers
{
    public class LoginController : ApiController
    {

        // GET: api/Login
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        //GET: api/Login/7620384419
        public string Get(int id)
        {
            //var user = new DbContext().GetUserByPhone(phone);
            //return Ok();
            return "Hello";
        }

        // POST: api/Login
        public int Post(object data)
        {
            int userId = 0;
            try
            {
                DbContext dbContext = new DbContext();
                userId = dbContext.Login(data);
            }
            catch (Exception ex)
            {
            }
            if (userId != 0)
            {
                return userId;
            }
            else
            {
                return 0;
            }
        }

        

    }
}
