﻿using DigitalWallet.Models;
using OnlineDigitalWallet.Models;
using OnlineDigitalWallet.Scripts;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace OnlineDigitalWallet.DataAccess
{
    public class DataAccessLayer
    {
        public int Authenticate(Credentials credentials)
        {
            int userId = 0;
            try
            {
                string strSqlConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
                SqlConnection scon = new SqlConnection(strSqlConnectionString);
                SqlCommand scmd = new SqlCommand("sp_AuthenticateUser", scon);
                scmd.CommandType = System.Data.CommandType.StoredProcedure;

                scmd.Parameters.AddWithValue("@phone", credentials.Email);
                scmd.Parameters.AddWithValue("@email", credentials.Email);
                scmd.Parameters.AddWithValue("@password", credentials.Password);

                SqlParameter outParameter = new SqlParameter();
                outParameter.ParameterName = "@UserId";
                outParameter.Direction = System.Data.ParameterDirection.Output;
                outParameter.SqlDbType = System.Data.SqlDbType.Int;


                scmd.Parameters.Add(outParameter);
                scon.Open();
                scmd.ExecuteNonQuery();
                scon.Close();
                userId = (int)outParameter.Value;
            }
            catch (Exception ex)
            {

            }
            return userId;
        }
        public int RegisterUser(Users user)
        {
            int userId = 0;
            try
            {
                string strSqlConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
                SqlConnection scon = new SqlConnection(strSqlConnectionString);
                SqlCommand scmd = new SqlCommand("sp_RegisterUser", scon);
                scmd.CommandType = System.Data.CommandType.StoredProcedure;

                scmd.Parameters.AddWithValue("@phone", user.Phone);
                scmd.Parameters.AddWithValue("@email", user.Email);
                scmd.Parameters.AddWithValue("@name", user.FirstName + " " + user.LastName);
                if (user.Gender == "male")
                    scmd.Parameters.AddWithValue("@gender", 1);
                else
                    scmd.Parameters.AddWithValue("@gender", 2);
                scmd.Parameters.AddWithValue("@pass", user.Password);

                SqlParameter outParameter = new SqlParameter();
                outParameter.ParameterName = "@UserId";
                outParameter.Direction = System.Data.ParameterDirection.Output;
                outParameter.SqlDbType = System.Data.SqlDbType.Int;


                scmd.Parameters.Add(outParameter);
                scon.Open();
                scmd.ExecuteNonQuery();
                scon.Close();
                userId = (int)outParameter.Value;

            }
            catch (Exception e)
            {

            }

            return userId;
        }
        public Users GetUserById(int id)
        {
            Users user = new Users();
            try
            {
                string strSqlConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
                SqlConnection scon = new SqlConnection(strSqlConnectionString);
                SqlDataAdapter sda = new SqlDataAdapter("select * from tblUsers where id = " + id, scon);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {

                    string[] name = ds.Tables[0].Rows[0]["name"].ToString().Split();
                    user.FirstName = name[0];
                    user.LastName = name[1];
                    user.Email = ds.Tables[0].Rows[0]["email"].ToString();
                    user.Phone = ds.Tables[0].Rows[0]["phone"].ToString();
                    user.Password = "";

                    if (ds.Tables[0].Rows[0]["email"].ToString() == "1")
                        user.Gender = "Male";
                    else
                        user.Gender = "Female";
                }
            }
            catch (Exception)
            {

            }
            return user;
        }

        public Wallet GetWalletById(int id)
        {
            Wallet wallet = new Wallet();
            string strSqlConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection scon = new SqlConnection(strSqlConnectionString);
            SqlDataAdapter sda = new SqlDataAdapter("select * from tblWallet where userId = " + id, scon);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                wallet.Amount = (float)Convert.ToDouble(ds.Tables[0].Rows[0]["amount"]);
                wallet.WalletId = (int)ds.Tables[0].Rows[0]["id"];
                wallet.UserId = id;
            }
            return wallet;
        }
        public void AddMoney(int id, float amount)
        {
            string strSqlConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection scon = new SqlConnection(strSqlConnectionString);
            SqlCommand scmd = new SqlCommand("sp_AddMoney", scon);
            scmd.CommandType = System.Data.CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@uid", id);
            scmd.Parameters.AddWithValue("@amount", amount);
            scon.Open();
            scmd.ExecuteNonQuery();
            scon.Close();
        }

        public string SendMoney(int id, SendMoney objSendMoney)
        {
            string strSqlConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection scon = new SqlConnection(strSqlConnectionString);
            SqlCommand scmd = new SqlCommand("sp_SendMoney", scon);
            scmd.CommandType = System.Data.CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@sender", id);
            scmd.Parameters.AddWithValue("@receiver", objSendMoney.ReceiverPhone);
            scmd.Parameters.AddWithValue("@transType", 1);
            scmd.Parameters.AddWithValue("@amount", objSendMoney.Amount);
            if (objSendMoney.Comment != null)
            {
                scmd.Parameters.AddWithValue("@comment", objSendMoney.Comment);
            }
            else
            {
                scmd.Parameters.AddWithValue("@comment", "Money debited");
            }

            SqlParameter outParameter = new SqlParameter();
            outParameter.ParameterName = "@name";
            outParameter.Direction = System.Data.ParameterDirection.Output;
            outParameter.SqlDbType = System.Data.SqlDbType.NVarChar;
            outParameter.Size = 15;
            scmd.Parameters.Add(outParameter);

            scon.Open();
            scmd.ExecuteNonQuery();
            scon.Close();
            string receiverName = (string)outParameter.Value;
            return receiverName;
        }

        public List<Transaction> GetTransactions(int id)
        {
            List<Transaction> transactions = new List<Transaction>();
            string strSqlConnectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection scon = new SqlConnection(strSqlConnectionString);
            SqlCommand scmd = new SqlCommand("sp_GetTransactions", scon);
            scmd.CommandType = System.Data.CommandType.StoredProcedure;
            scmd.Parameters.AddWithValue("@sender", id);
            SqlDataAdapter sda = new SqlDataAdapter(scmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    Transaction transaction = new Transaction();
                    transaction.Amount = (float)Convert.ToDouble(ds.Tables[0].Rows[i]["amount"]);
                    transaction.Comment = ds.Tables[0].Rows[i]["details"].ToString();
                    transaction.Receiver = (int)ds.Tables[0].Rows[i]["receiver"];
                    transaction.TransactionId = (int)ds.Tables[0].Rows[i]["id"];
                    transaction.TransactionDateTime = Convert.ToDateTime(ds.Tables[0].Rows[i]["tranDateTime"]);
                    transaction.TransactionType = (int)ds.Tables[0].Rows[i]["transType"];
                    transaction.Sender = id;
                    transaction.ReceiverName = ds.Tables[0].Rows[i]["name"].ToString();
                    transaction.ReceiverNumber = ds.Tables[0].Rows[i]["phone"].ToString();
                    transaction.Status = (int)ds.Tables[0].Rows[i]["transStatus"];
                    transactions.Add(transaction);
                }
            }
            return transactions;
        }

    }
}