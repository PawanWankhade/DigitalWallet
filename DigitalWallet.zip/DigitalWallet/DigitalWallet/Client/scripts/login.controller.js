﻿app.controller("LoginController", function ($scope, $http, $location, $cookies, $rootScope) {

    (function initController() {
        // AuthenticationService.ClearCredentials();
        $rootScope.globals = {};
        $cookies.remove('globals');
        $http.defaults.headers.common.Authorization = 'Basic';
        //        alert("callled");
    })();
    $scope.userName;
    $scope.password;
    $scope.login = function () {
        $scope.dataLoading = true;
        var viewModel = {
            Email: $scope.userName,
            Password: $scope.password,
            RememberMe: true
        };
        $http({
            method: "POST",
            url: "/api/Login",
            data: viewModel,
        }).success(function (response) {
            if (response != 0) {
               // alert("success");
                var authdata = Base64.encode($scope.userName + ':' + $scope.password);
                $rootScope.globals = {
                    currentUser: {
                        username: response,
                        name:'',
                        authdata: authdata
                    }
                };

                // set default auth header for http requests
                $http.defaults.headers.common['Authorization'] = 'Basic ' + authdata;

                // store user details in globals cookie that keeps user logged in for 1 week (or until they logout)
                var cookieExp = new Date();
                cookieExp.setDate(cookieExp.getDate() + 7);
                $cookies.putObject('globals', $rootScope.globals, { expires: cookieExp });
                $location.path('/home');
            } else {
                //alert("Login failed");
                $scope.message = "Please check user id or password.";
                $scope.dataLoading = false;
            }
        })
        .error(function (response) {
            alert("Unable to contact server");
        });
    };
});