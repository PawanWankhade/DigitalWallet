﻿var app = angular.module("WalletApp", ["ngRoute", "ngCookies"]);

app.config(function ($routeProvider) {
    $routeProvider
    //.when("/",
    //{ templateUrl: "Client/Views/index.html" })
    .when("/login",
    { templateUrl: "Client/Views/login.html" })
    .when("/register",
    { templateUrl: "Client/Views/register.html" })
    .when("/home",
    { templateUrl: "Client/Views/User/home.html" })
    .when("/addMoney",
    { templateUrl: "Client/Views/User/addMoney.html " })
    .when("/sendMoney",
    { templateUrl: "Client/Views/User/sendMoney.html " })
    .when("/transactions",
    { templateUrl: "Client/Views/User/transactions.html " })
.otherwise(
    { redirectTo: "/login" });


});

//run.$inject = ['$rootScope', '$location', '$cookies', '$http'];
app.run(function ($rootScope, $location, $cookies, $http) {
    $rootScope.globals = $cookies.getObject('globals') || {};
    if ($rootScope.globals.currentUser) {
        $http.defaults.headers.common['Autherization'] = 'Basic' + $rootScope.globals.currentUser.authdata;
    }

    $rootScope.$on('$locationChangeStart', function (event, next, current) {
        // redirect to login page if not logged in and trying to access a restricted page
        var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
        var loggedIn = $rootScope.globals.currentUser;
        if (restrictedPage && !loggedIn) {
            $location.path('/login');
        }
    });
});




