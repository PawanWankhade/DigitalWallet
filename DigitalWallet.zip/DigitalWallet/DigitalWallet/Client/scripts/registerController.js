﻿app.controller("RegisterController", function ($scope, $http,$location) {

    $scope.dataLoading = false;

    $scope.user = {};
    $scope.user.gender = 'male';
    $scope.register = function () {
        $scope.dataLoading = true;
        var viewModel = {
            FirstName: $scope.user.firstName,
            LastName: $scope.user.lastName,
            Email: $scope.user.email,
            Phone: $scope.user.phone,
            Gender: $scope.user.gender,
            Password: $scope.user.password
        };
        $http({
            method: "POST",
            url: "/api/Users",
            data: viewModel,
        }).success(function (response) {
            if (response) {
                alert("success");
                $location.path('/login');
            } else {
                alert("Login failed");
            }
        })
        .error(function (response) {
            alert("Unable to contact server...");
            $scope.message = "Login failed";
        });

    };

});