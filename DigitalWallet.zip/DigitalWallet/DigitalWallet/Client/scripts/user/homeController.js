﻿app.controller("HomeController", function ($scope, $rootScope, $cookies, $http, UserService, $location) {
    $scope.message = "";
    

    (function initController() {
        UserService.GetById($rootScope.globals.currentUser.username)
        .then(function (response) {
            $scope.user = response.data;
            $rootScope.globals.currentUser.name = $scope.user.FirstName;

        });

        UserService.GetWalletDetails($rootScope.globals.currentUser.username)
        .then(function (response) {
            $scope.wallet = response.data;
        });

        //$http.get("/api/Wallet/" + $rootScope.globals.currentUser.username)
        //    .success(function (response) {
        //        $scope.wallet = response;
        //    });

    })();


    $scope.LogOut = ClearCredentials;
    function ClearCredentials() {
        alert("logout called");
        $rootScope.globals = {};
        $cookies.remove('globals');
        $http.defaults.headers.common.Authorization = 'Basic';
    };

    $scope.amount;
    $scope.addMoney = function () {
        //alert("add money called");
        $http.put("api/Wallet/" + $rootScope.globals.currentUser.username, $scope.amount)
            .success(function (response) {
                $scope.message = "Money added successfully";
                $scope.amount = '';
                //$location.path('/home');
            })
            .error(function (response) {
                $scope.message = "Transaction failed";
            });
    };


    $scope.paymentOption = "credit";
    
   
});
