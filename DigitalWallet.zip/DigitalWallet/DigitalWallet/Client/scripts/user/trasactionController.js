﻿app.controller("TransactionController", function ($scope, $rootScope, $http, $location, UserService) {
    $scope.receiver;
    $scope.comment;

    UserService.GetWalletDetails($rootScope.globals.currentUser.username)
       .then(function (response) {
           $scope.wallet = response.data;
       });

    $scope.sendMoney = function () {
       // alert("send money called");

        if ($scope.amount > $scope.wallet.Amount) {
            //   alert('Not enough money in wallet');
            $scope.message = "Not enough money in wallet";
        }
        else {
            var data = {
                Sender: $rootScope.globals.currentUser.username,
                ReceiverPhone: $scope.receiver,
                Amount: $scope.amount,
                Comment: $scope.comment
            };
            $http.put("api/Transaction/" + $rootScope.globals.currentUser.username, data)
                .success(function (response) {
                    //alert("money transfered to " + response);
                    $scope.message = "Money transfered to " + response;
                    //$location.path("/home");
                });

        }
    };
    UserService.GetTransactions($rootScope.globals.currentUser.username)
       .then(function (response) {
           $scope.transactions = response.data;
           bindTransactions();
       });
    function bindTransactions() {

        //alert($scope.transactionModel[0].Amount);
        var trData = $scope.transactions;
        for (var i = 0; i < trData.length; i++) {
            if (trData[i].Sender == trData[i].Receiver) {
                // $scope.transactions[i].TransactionType = "Money added to OnePay";
                $scope.transactions[i].MerchantName = "Added to OnePay Wallet";
                //$scope.transactions[i].ReceiverName = "Added to OnePay Wallet";
                //$scope.transactions[i].TransactionType = "Credit";
                $scope.transactions[i].ReceiverName = "none";
                if (trData[i].TransactionType == 1) {
                    $scope.transactions[i].MerchantName = "Added to OnePay Wallet";
                    //$scope.transactions[i].ReceiverName = "OnePay Cash sent";
                    $scope.transactions[i].TransactionType = "Debit";
                }
                else {
                    $scope.transactions[i].TransactionType = "Credit";
                    $scope.transactions[i].MerchantName = "Added to OnePay Wallet";
                }

            }
            else {
                if (trData[i].TransactionType == 1) {
                    //$scope.transactions[i].ReceiverName = "OnePay Cash sent";
                    $scope.transactions[i].TransactionType = "Debit";
                    $scope.transactions[i].MerchantName = "OnePay Cash sent";
                }
                else {
                    $scope.transactions[i].TransactionType = "Credit";
                    $scope.transactions[i].MerchantName = "OnePay Cash sent";
                }
            }

            //Status
            if (trData[i].Status == 1) {
                $scope.transactions[i].Status = "Success";
            }
            else {
                $scope.transactions[i].Status = "Failed";
            }


        }
    };





});

