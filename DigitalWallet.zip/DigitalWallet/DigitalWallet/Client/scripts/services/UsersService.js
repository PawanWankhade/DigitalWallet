﻿app.factory('UserService', function ($http) {
    var service = {};

    service.GetAll = function () {
        return $http.get('/api/users').then(handleSuccess, handleError('Error getting all users'));
    };

    service.GetById = function (id) {
        return $http.get('/api/Users/' + id).then(handleSuccess, handleError('Error getting user by id'));
    };

    service.GetByEmail = function (userName) {
        return $http.get('/api/users/' + username).then(handleSuccess, handleError('Error getting user by username'));
    };

    service.CreateUser = function (user) {
        return $http.post('/api/users', user).then(handleSuccess, handleError('Error creating user'));
    };

    service.GetWalletDetails = function (id) {
        return $http.get("/api/Wallet/" + id).then(handleSuccess, handleError('Error getting wallet'));
    };

    service.GetTransactions = function (id) {
        return $http.get("/api/Transaction/" + id).then(handleSuccess, handleError('Error getting Transaction'));
    };

    // private functions

    function handleSuccess(res) {
        return res;
    }

    function handleError(error) {
        return function () {
            return { success: false, message: error };
        };
    }


    return service;
});

